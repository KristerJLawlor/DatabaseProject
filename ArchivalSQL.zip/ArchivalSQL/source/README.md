To install the necessary dependencies, type "pip3 install -r requirements.txt".
